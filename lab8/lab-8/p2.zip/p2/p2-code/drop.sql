drop table restaurant;
drop table locality;
drop table reviews;
drop table account;
